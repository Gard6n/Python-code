from PIL import Image
cake = Image.open("penguin.jpg")
width, height = cake.size
print(f'{width}, {height}')
pix = cake.load()
r, g, b = pix[100, 200]
pix[100, 200] = (r, g, b)
cake.show()